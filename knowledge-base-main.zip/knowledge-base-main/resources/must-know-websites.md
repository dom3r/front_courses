
Social / blogs /magazine  
[https://dev.to/](https://dev.to/)  
[https://stackoverflow.com/](https://stackoverflow.com/)  
[https://www.smashingmagazine.com/](https://www.smashingmagazine.com/)  
[https://medium.com/](https://medium.com/)  
[https://css-tricks.com/](https://css-tricks.com/)  
[https://www.codewars.com/](https://www.codewars.com/)  

Docs/knowledge/standards:  
[https://developer.mozilla.org/en-US/](https://developer.mozilla.org/en-US/)  
[https://caniuse.com/](https://caniuse.com/)  
[https://validator.w3.org/nu/](https://validator.w3.org/nu/)

Tooling  
[https://codepen.io/](https://codepen.io/)  
[https://stackblitz.com/](https://stackblitz.com/)  
[https://github.com/mdbootstrap](https://github.com/mdbootstrap)  
[https://www.browserstack.com/](https://www.browserstack.com/)  
[https://coolors.co/](https://coolors.co/)  
[https://hoppscotch.io/](https://hoppscotch.io/)

Learning  
[https://learngitbranching.js.org/](https://learngitbranching.js.org/)  
[https://www.freecodecamp.org/](https://www.freecodecamp.org/)  
[https://www.youtube.com/](https://www.youtube.com/)  
[https://www.w3schools.com/](https://www.w3schools.com/)
[https://www.udemy.com/](https://www.udemy.com/)  
[https://www.sql-ex.ru/](https://www.sql-ex.ru/)  

Design:  
[https://www.awwwards.com/](https://www.awwwards.com/)  
[https://dribbble.com/](https://dribbble.com/)

Misc  
[https://www.google.com/](https://www.google.com/)
