<h1>Sign up for a my newsletter:</h1>


<form action="subscribe.php" method="post">
    <label for="firstname"> <input type="text" name="firstname"> First name</label> <br>
    <label for="lastname"> <input type="text" name="lastname"> Last name</label><br>
    <label for="email"> <input type="text" name="email"> Email: name</label><br>
    <input type="submit" name="submit" value="Subscribe">
</form>