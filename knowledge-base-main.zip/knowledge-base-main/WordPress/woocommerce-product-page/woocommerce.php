<?php get_header(); ?>

<div class="container">
    <?php
    woocommerce_content();
    ?>
</div>

<?php get_footer(); ?>